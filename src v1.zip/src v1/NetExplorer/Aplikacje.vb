﻿Public Class Aplikacje
    Private Sub Bitly_Click(sender As Object, e As EventArgs) Handles Bitly.Click
        Bitlyp.Show()
    End Sub
End Class