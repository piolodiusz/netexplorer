﻿Public Class Informacje

End Class